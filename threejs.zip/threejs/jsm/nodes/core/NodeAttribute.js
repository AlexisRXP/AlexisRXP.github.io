class NodeAttribute {

	constructor( name, type ) {

		this.isNodeAttribute = true;

		this.name = name;
		this.type = type;

	}

}

export default NodeAttribute;
